# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle
import seaborn as sns
import datetime


df = pd.read_csv('./Production_data.csv')
# df.head()

df=df.drop('Unnamed: 0',axis=1)
date=pd.to_datetime(df['DATEPRD'])
df['date']=date


plt.figure(figsize=(15,6))
plt.title("Oil production for all wells")
sns.lineplot(data = df ,x =date, y = "BORE_OIL_VOL" ,hue ="NPD_WELL_BORE_CODE",)



from sklearn.preprocessing import MinMaxScaler
dfnew = df.drop(['DATEPRD' , 'NPD_WELL_BORE_CODE','date'], axis=1)
scaler_all_data = MinMaxScaler()
data_scaled = scaler_all_data.fit_transform(dfnew)
df_data_scaled=pd.DataFrame(data_scaled)
# df_data_scaled.head(5)



dfnew= df.filter(['ON_STREAM_HRS','AVG_DOWNHOLE_PRESSURE','AVG_DP_TUBING','AVG_WHP_P','AVG_WHT_P','DP_CHOKE_SIZE','BORE_OIL_VOL', 'BORE_GAS_VOL'], axis=1)
X = dfnew.filter(['DATEPRD','NPD_WELL_BORE_CODE','ON_STREAM_HRS', 'AVG_DOWNHOLE_PRESSURE', 'AVG_DP_TUBING', 'AVG_WHP_P', 'AVG_WHT_P', 'DP_CHOKE_SIZE'])
Y = dfnew[['BORE_OIL_VOL']]
# print('Features shape:', X.shape)
# print('Target shape', Y.shape)
# print(X)
# Train-test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.3, random_state=42, shuffle = True)


Time=df.iloc[:,0]
Time_train, Time_test = train_test_split(Time, test_size=0.3, random_state=42)


from sklearn import metrics
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.metrics import explained_variance_score
from pprint import pprint
from math import sqrt
from sklearn.ensemble import RandomForestRegressor
rf = RandomForestRegressor(random_state=0).fit(X_train, y_train) #Random_state is the seed used by the random number generator
predictions_rf = rf.predict(X_test)
# Metrics
# print('Model score:',              round(rf.score(X_test, y_test),2))
# print('Mean absolute error:',      round(mean_absolute_error(y_test, predictions_rf),2))
# print('Root mean squared error:',  round(sqrt(mean_squared_error(y_test, predictions_rf)),2))
# print('R2:',                       round(r2_score(y_test, predictions_rf),2))
# rf.score(X_test,y_test)

# Saving model to disk
pickle.dump(rf, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
# print(model.predict([[2, 9, 6]]))