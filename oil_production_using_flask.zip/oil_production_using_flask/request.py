import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'ON_STREAM_HRS':24.0,'AVG_DOWNHOLE_PRESSURE':289.421362,'AVG_DP_TUBING':182.059312,'AVG_WHP_P':107.362050,'AVG_WHT_P':37.939251,'DP_CHOKE_SIZE':78.935409})

print(r.json())